package com.nseindia.b2.blogger.services;

import java.util.List;

import com.nseindia.b2.blogger.entities.Blogger;

public interface BloggerService {
	public List<Blogger> getAll();

	public Blogger get(Long id);

	public Blogger put(Blogger blogger);

	public Blogger update(Long id, Blogger Blogger);

	public Blogger delete(Long id);

}
 