package com.nseindia.b2.blogger.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nseindia.b2.blogger.entities.Blogger;
import com.nseindia.b2.blogger.models.Request;
import com.nseindia.b2.blogger.models.Response;
import com.nseindia.b2.blogger.services.BloggerService;

@RestController
public class BloggerController {
	
	@Autowired
	BloggerService service;
	
//	@GetMapping("/")
//	public ResponseList getall() {
//		ResponseList resp = new ResponseList();
//		resp.setMessage("list found");
//		resp.setBlogger(service.getAll());
//		
//		
//		return resp;
//		
//	}
	
	@GetMapping("/{id}")
	public Response get(@PathVariable Long id) {
		Response resp=new Response();
		resp.setBlogger(service.get(id));
		if(resp.blogger!=null) {
			resp.setMessage("record retrieved sucessfully");
			
		}else {
			resp.setMessage("no records found");
		}
			
			
		return resp;
	}
	
	@PostMapping("/")
	public Response put(@RequestBody Request request ) {
		Blogger blogger =request.toblogger();
			blogger=service.put(blogger);
			Response resp= new Response();
				resp.setBlogger(blogger);
				resp.setMessage("record added");
			
			return resp;
	}
	
	@PutMapping("/{id}")
	public Response update(@PathVariable("id")Long id,@RequestBody Request request) {
		Response resp= new Response();
		Blogger blogger=request.toblogger();
		blogger=service.update(id, blogger);
		if(blogger !=null) {
			resp.setBlogger(blogger);
			resp.setMessage("record updated sucessfully");
			
		}else {
			resp.setMessage("not found");
		}
		return resp;
	}
	
	
	@DeleteMapping("/{id}")
	public Response delete(@PathVariable("id") Long id) {
		Response resp=new Response();
		Blogger blogger=service.delete(id);
		if(blogger!=null) {
			resp.setBlogger(blogger);
			resp.setMessage("record deleted sucessfull");
			
		}else {
			resp.setMessage("not found");
		}
		
		
		return resp;
	}

}