package com.nseindia.b2.blogger.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nseindia.b2.blogger.entities.Blogger;
import com.nseindia.b2.blogger.repositories.Repository;

@Service
public class BloggerServiceIMPL implements BloggerService {
	@Autowired
	Repository repo;
																	

	@Override
	public List<Blogger> getAll() {
		List<Blogger> bloggerlist =new ArrayList<Blogger>();
		repo.findAll().forEach(a -> {
			bloggerlist.add(a);
		});
		return bloggerlist;
	}

	@Override
	public Blogger get(Long id) {
		Blogger blog =new Blogger();
		blog=repo.findById(id).orElse(null);
		return blog;
	}

	@Override
	public Blogger put(Blogger blogger) {
		blogger.setId(null);
		blogger=repo.save(blogger);
		return blogger;
	}

	@Override
	public Blogger update(Long id, Blogger Blogger) {
		Blogger a=repo.findById(id).orElse(null);
		if(a!=null){
			if(Blogger.getTitle()!=null) {
				a.setTitle(Blogger.getTitle());
			}
			if(Blogger.getBody()!=null) {
				a.setBody(Blogger.getBody());
			}
			if(Blogger.getSummary()!=null) {
				a.setSummary(Blogger.getSummary());
			}
			repo.save(a);
			return a;
		
		}
		return null;
	}

	@Override
	public Blogger delete(Long id) {

Blogger blogger=repo.findById(id).orElse(null);
if(blogger!=null) {
	repo.deleteById(id);
}
		return blogger;
	}

}