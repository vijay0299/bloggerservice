package com.nseindia.b2.blogger.models;

import com.nseindia.b2.blogger.entities.Blogger;

public class Response {
	public Blogger blogger;
	public String message;

	public Blogger getBlogger() {
		return blogger;
	}

	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Response [blogger=" + blogger + ", message=" + message + "]";
	}

}
